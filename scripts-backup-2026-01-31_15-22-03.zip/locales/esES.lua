-- esES localization
local L = LibStub("AceLocale-3.0"):NewLocale("GW2_UI", "esES")
if not L then return end

--Strings
--@localization(locale="esES", format="lua_additive_table", handle-unlocalized="ignore")@