-- frFR localization
local L = LibStub("AceLocale-3.0"):NewLocale("GW2_UI", "frFR")
if not L then return end

--Strings
--@localization(locale="frFR", format="lua_additive_table", handle-unlocalized="ignore")@