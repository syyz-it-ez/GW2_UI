-- zhCN localization
local L = LibStub("AceLocale-3.0"):NewLocale("GW2_UI", "zhCN")
if not L then return end

--Strings
--@localization(locale="zhCN", format="lua_additive_table", handle-unlocalized="ignore")@