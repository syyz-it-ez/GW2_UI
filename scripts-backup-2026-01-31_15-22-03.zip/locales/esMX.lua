-- esMX localization
local L = LibStub("AceLocale-3.0"):NewLocale("GW2_UI", "esMX")
if not L then return end

--Strings
--@localization(locale="esMX", format="lua_additive_table", handle-unlocalized="ignore")@