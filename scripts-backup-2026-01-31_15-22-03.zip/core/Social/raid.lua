local _, GW = ...

local function UpdateRaidFrame()
    local update = RaidFrame_Update or (RaidFrame and RaidFrame.Update)
    if update then
        update(RaidFrame)
    end
end

local function RaidInfoFrameUpdate()
    local update = RaidInfoFrame_Update or (RaidInfoFrame and RaidInfoFrame.UpdateRaids)
    if update then
        update(RaidInfoFrame)
    end
end

local function RaidGroupButton_OnDragStart(raidButton)
    if InCombatLockdown() then return end
    if ( not UnitIsGroupLeader("player") and not UnitIsGroupAssistant("player") ) then
        return;
    end
    raidButton:StartMoving();
    MOVING_RAID_MEMBER = raidButton;
end

local function RaidGroupButton_OnDragStop(raidButton)
    if InCombatLockdown() then return end
    if ( not UnitIsGroupLeader("player") and not UnitIsGroupAssistant("player") ) then
        return;
    end

    raidButton:StopMovingOrSizing();
    raidButton:ClearAllPoints();
    raidButton:SetPoint("TOPLEFT", raidButton.slot, "TOPLEFT", 0, 0);

    MOVING_RAID_MEMBER = nil;
    if ( TARGET_RAID_SLOT and TARGET_RAID_SLOT:GetParent():GetID() ~= raidButton.subgroup ) then
        if (TARGET_RAID_SLOT.button) then
            local button = _G[TARGET_RAID_SLOT.button];
            SwapRaidSubgroup(raidButton:GetID(), button:GetID());
        else
            local slot = TARGET_RAID_SLOT:GetParent():GetName().."Slot"..TARGET_RAID_SLOT:GetParent().nextIndex;
            raidButton:ClearAllPoints();
            raidButton:SetPoint("TOPLEFT", slot, "TOPLEFT", 0, 0);
            TARGET_RAID_SLOT:UnlockHighlight();
            SetRaidSubgroup(raidButton:GetID(), TARGET_RAID_SLOT:GetParent():GetID());
        end
    else
        if ( TARGET_RAID_SLOT ) then
            TARGET_RAID_SLOT:UnlockHighlight();
        end
    end
end

local function RaidFrame_OnEvent(self, event, ...)
    if event == "PLAYER_REGEN_ENABLED" then
        self:UnregisterEvent("PLAYER_REGEN_ENABLED")
        UpdateRaidFrame()
    end

    if ( event == "PLAYER_ENTERING_WORLD" ) then
        RequestRaidInfo();
    elseif ( event == "PLAYER_LOGIN" ) then
        if ( IsInRaid() ) then
            RaidFrame_LoadUI();
            if not InCombatLockdown() then UpdateRaidFrame() end
        end
    elseif ( event == "GROUP_ROSTER_UPDATE" ) then
        RaidFrame_LoadUI();
        if InCombatLockdown() then
            self:RegisterEvent("PLAYER_REGEN_ENABLED")
        else
            UpdateRaidFrame()
        end
        RaidPullout_RenewFrames();
    elseif ( event == "READY_CHECK" or
        event == "READY_CHECK_CONFIRM" ) then
        if ( RaidFrame:IsShown() and RaidGroupFrame_Update and not InCombatLockdown() ) then
            RaidGroupFrame_Update();
        end
    elseif ( event == "READY_CHECK_FINISHED" ) then
        if ( RaidFrame:IsShown() and RaidGroupFrame_ReadyCheckFinished ) then
            RaidGroupFrame_ReadyCheckFinished();
        end
    elseif ( event == "UPDATE_INSTANCE_INFO" ) then
        if ( not RaidFrame.hasRaidInfo ) then
            -- Set flag
            RaidFrame.hasRaidInfo = 1;
            return;
        end
        if ( GetNumSavedInstances() + GetNumSavedWorldBosses() > 0 ) then
            RaidFrameRaidInfoButton:Enable();
        else
            RaidFrameRaidInfoButton:Disable();
        end
        RaidInfoFrameUpdate()
    elseif (event == "PARTY_LEADER_CHANGED" or event == "PARTY_LFG_RESTRICTED" ) then
        if InCombatLockdown() then
            self:RegisterEvent("PLAYER_REGEN_ENABLED")
        else
            UpdateRaidFrame()
        end
    end
end

local function RaidGroupFrame_OnEvent(self, event, ...)
    if event == "PLAYER_REGEN_ENABLED" then
        self:UnregisterEvent("PLAYER_REGEN_ENABLED")
        RaidGroupFrame_Update()
    end

    RaidFrame_OnEvent(self, event, ...);
    if ( event == "UNIT_LEVEL" ) then
        local arg1 = ...;
        local id, found = gsub(arg1, "raid([0-9]+)", "%1");
        if ( found == 1 ) then
            RaidGroupFrame_UpdateLevel(id);
        end
    elseif ( event == "UNIT_HEALTH" ) then
        local arg1 = "...";
        local id, found = gsub(arg1, "raid([0-9]+)", "%1");
        if ( found == 1 ) then
            RaidGroupFrame_UpdateHealth(id);
        end
    elseif ( event == "UNIT_PET" or event == "UNIT_NAME_UPDATE" ) then
        RaidClassButton_Update();
    elseif ( event == "PLAYER_ENTERING_WORLD" ) then
        RaidPullout_RenewFrames();
    elseif ( event == "VARIABLES_LOADED" ) then
        RaidFrame.showRange = GetCVarBool("showRaidRange");
    elseif ( event == "RAID_ROSTER_UPDATE" and not InCombatLockdown() ) then
        if InCombatLockdown() then
            self:RegisterEvent("PLAYER_REGEN_ENABLED")
        else
            RaidGroupFrame_Update()
        end
    end
end

local function LoadRaidList(tabContainer)
    RaidFrame_LoadUI()
    UpdateRaidFrame()
    RequestRaidInfo()

    RaidFrame:SetScript("OnEvent", RaidGroupFrame_OnEvent);

    local raidFrame = CreateFrame("Frame", "GwRaidWindow", tabContainer, "GWRaidFrameSocial")

    RaidFrame:SetParent(raidFrame)
    RaidFrame:ClearAllPoints()
    RaidFrame:SetPoint("TOPLEFT", raidFrame, "TOPLEFT", 0, 0)
    RaidFrame:SetPoint("BOTTOMRIGHT", raidFrame, "BOTTOMRIGHT", 0, 0)

    RaidFrame:SetScript("OnShow", function(self)
        if GW.Retail then
            ButtonFrameTemplate_ShowAttic(self:GetParent())
        end

        if InCombatLockdown() then
            self:RegisterEvent("PLAYER_REGEN_ENABLED")
        else
            UpdateRaidFrame()
        end
        RequestRaidInfo()
    end)

    if RaidFrameNotInRaid.ScrollingDescription then
        RaidFrameNotInRaid.ScrollingDescription:ClearAllPoints()
        RaidFrameNotInRaid.ScrollingDescription:SetPoint("TOPLEFT", RaidFrameNotInRaid, "TOPLEFT", 0, -73)
        RaidFrameNotInRaid.ScrollingDescription:SetPoint("BOTTOMRIGHT", RaidFrameNotInRaid, "BOTTOMRIGHT", 0, 0)
        RaidFrameNotInRaid.ScrollingDescription.ScrollBox.FontStringContainer.FontString:SetJustifyH("CENTER")
        RaidFrameNotInRaid.ScrollingDescription.ScrollBox.FontStringContainer.FontString:SetJustifyV("TOP")
        RaidFrameNotInRaid.ScrollingDescription.ScrollBox.FontStringContainer.FontString:SetTextColor(1, 1, 1)
    end

    RaidFrameAllAssistCheckButton:ClearAllPoints()
    RaidFrameAllAssistCheckButton:SetPoint("TOPLEFT", 10, -23)
    RaidFrameAllAssistCheckButton.text:ClearAllPoints()
    RaidFrameAllAssistCheckButton.text:SetPoint("LEFT", RaidFrameAllAssistCheckButton, "RIGHT", 5, -2)
    RaidFrameAllAssistCheckButton.text:SetText(ALL .. " |TInterface/AddOns/GW2_UI/textures/party/icon-assist.png:25:25:0:-3|t")

    --ALL_ASSIST_LABEL
    if RaidFrame.RoleCount then
        RaidFrame.RoleCount:ClearAllPoints()
        RaidFrame.RoleCount:SetPoint("TOP", -80, -25)

        RaidFrame.RoleCount.TankIcon:SetTexture("Interface/AddOns/GW2_UI/textures/party/roleicon-tank.png")
        RaidFrame.RoleCount.HealerIcon:SetTexture("Interface/AddOns/GW2_UI/textures/party/roleicon-healer.png")
        RaidFrame.RoleCount.DamagerIcon:SetTexture("Interface/AddOns/GW2_UI/textures/party/roleicon-dps.png")
        RaidFrame.RoleCount.DamagerIcon:SetSize(20, 20)
    end

    RaidFrameAllAssistCheckButton:GwSkinCheckButton()
    RaidFrameAllAssistCheckButton:SetSize(18, 18)

    if RaidFrameReadyCheckButton then
        RaidFrameReadyCheckButton:GwSkinButton(false, true)
    end

    RaidFrameConvertToRaidButton:GwSkinButton(false, true)
    RaidFrameRaidInfoButton:GwSkinButton(false, true)
    if GW.settings.USE_CHARACTER_WINDOW and (GW.Retail or GW.Mists) then
        RaidFrameRaidInfoButton:SetScript("OnClick", function()
            if InCombatLockdown() then return end
            if GwCharacterCurrencyRaidInfoFrame.RaidLocks:IsVisible() then
                GwCharacterWindow:SetAttribute("windowpanelopen", "nil")
                return
            end
            GwCharacterWindow:SetAttribute("windowpanelopen", "currency")
            GWCurrencyMenu.items.raidinfo:Click()
        end)
    end

    ClaimRaidFrame = GW.NoOp

    local StripAllTextures = {
        "RaidGroup1",
        "RaidGroup2",
        "RaidGroup3",
        "RaidGroup4",
        "RaidGroup5",
        "RaidGroup6",
        "RaidGroup7",
        "RaidGroup8",
    }

    for _, object in pairs(StripAllTextures) do
        local obj = _G[object]
        if obj then
            obj:SetSize(230, 120)
            obj:GwStripTextures()
            _G[object .. "Label"]:SetNormalFontObject("GameFontNormal")
            _G[object .. "Label"]:SetHighlightFontObject("GameFontHighlight")
            for j = 1, 5 do
                local slot = _G[object .. "Slot" .. j]
                if slot then
                    slot:GwStripTextures()
                    slot:SetSize(220, 22)
                    slot:GwCreateBackdrop(GW.BackdropTemplates.DefaultWithSmallBorder, true)
                end
            end
        end
    end

    for i = 1, _G.MAX_RAID_GROUPS * 5 do
        _G["RaidGroupButton" .. i]:SetSize(220, 22)
        _G["RaidGroupButton" .. i]:GwSkinButton(false, true, true)
        _G["RaidGroupButton" .. i]:GwStripTextures()
        _G["RaidGroupButton" .. i]:GwCreateBackdrop(GW.BackdropTemplates.DefaultWithSmallBorder, true)
        _G["RaidGroupButton" .. i .. "Name"]:SetFont(UNIT_NAME_FONT, 10)
        _G["RaidGroupButton" .. i .. "Level"]:SetFont(UNIT_NAME_FONT, 10)

        if _G["RaidGroupButton" .. i .. "Class"].SetFont then
            _G["RaidGroupButton" .. i .. "Class"]:SetFont(UNIT_NAME_FONT, 10)
        else
            _G["RaidGroupButton" .. i .. "Class"].text:SetFont(UNIT_NAME_FONT, 10)
        end

        _G["RaidGroupButton" .. i .. "Name"]:SetSize(60, 19)
        _G["RaidGroupButton" .. i .. "Level"]:SetSize(37, 19)
        _G["RaidGroupButton" .. i .. "Class"]:SetSize(80, 19)

        _G["RaidGroupButton" .. i]:SetScript("OnDragStart", RaidGroupButton_OnDragStart)
        _G["RaidGroupButton" .. i]:SetScript("OnDragStop", RaidGroupButton_OnDragStop)
    end

    hooksecurefunc("RaidGroupFrame_Update", function()
        for i = 1, _G.MAX_RAID_GROUPS * 5 do
            local _, rank, _, _, _, _, _, _, _, role = GetRaidRosterInfo(i)

            if rank == 2 then
                _G["RaidGroupButton" .. i .. "RankTexture"]:SetTexture("Interface/AddOns/GW2_UI/textures/party/icon-groupleader.png")
            elseif rank == 1 then
                _G["RaidGroupButton" .. i .. "RankTexture"]:SetTexture("Interface/AddOns/GW2_UI/textures/party/icon-assist.png")
            else
                _G["RaidGroupButton" .. i .. "RankTexture"]:SetTexture("")
            end

            if role == "MAINTANK" then
                _G["RaidGroupButton" .. i .. "RoleTexture"]:SetTexture("Interface/AddOns/GW2_UI/textures/party/icon-maintank.png")
            elseif role == "MAINASSIST" then
                _G["RaidGroupButton" .. i .. "RoleTexture"]:SetTexture("Interface/AddOns/GW2_UI/textures/party/icon-mainassist.png")
            else
                _G["RaidGroupButton" .. i .. "RoleTexture"]:SetTexture("")
            end
        end

    end)
end
GW.LoadRaidList = LoadRaidList